Please read the CONSET FORM before the experiment!


=================================================================================

Please extract the content (StoryGeneration.jar and Plotpoints.txt) and put them in the same folder. To start the program, double click StoryGeneration.jar (JVM is needed to run it).

You are going to read 50 plot points. After each plot point, please select your preference level for it on a 1-5 scale level (1 means least prefered and 5 means most prefered) and click "Next". 

After the experiment, please send the generated file "ratings.txt" located in the same folder to my email address: yuhong0519@gmail.com. 

(You are not required to finish all the 50 plot points. If you feel boring, you can stop it any time you want, continue it later, or just send me back the ratings.txt file:)

Thank you very much for you help!